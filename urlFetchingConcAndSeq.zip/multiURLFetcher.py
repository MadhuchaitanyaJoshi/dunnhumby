import json
import subprocess
import psutil
from subprocess import CREATE_NEW_CONSOLE
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen

with open("C:/Users/RAHUL/PycharmProjects/SparkProject/Mohit/conf.json", "r") as config:
    conf = json.load(config)
command = conf["command"]
loop_num = conf["loop_num"]
print(loop_num,type(loop_num))
concurrency = conf["concurrency"]
list_processes = {}
process = []


def urlFetch(url):
    print(" start at ",datetime.now()," of url ",url)
    response = urlopen(url)
    data_json = json.loads(response.read())
    print(data_json)
    print(" end at ",datetime.now()," of url ",url)

def concurrent_loop(command):
    urlFetch(command)
    #p = subprocess.Popen(command, shell=True, stdin=None, stdout=None, stderr=subprocess.PIPE, close_fds=True,universal_newlines=True,creationflags=CREATE_NEW_CONSOLE)
    print("started process",p.pid,datetime.now())
    #list_processes[p] = p.pid
    #pl = p.poll()
    #while( p.pid in psutil.pids()):
        #pass
    #print(p.pid, "stopped",p.pid,datetime.now())

"""def tracer(processes):
    print(psutil.pids())
    print("inside poller")
    while (len(processes) != 0):
        for child, value in processes.copy().items():
            p = child.poll()
            if(child.pid in psutil.pids()):
                pass
            else:
                print(child.pid,"stopped")
                del processes[child]
"""
def launch_concurrent_loop(command):
    #lst_commands= [command for i in range(0,loop_num)]
    #print(lst_commands)
    with ThreadPoolExecutor(max_workers=len(command)) as executor:
        executor.map(concurrent_loop,command)

def sequential_loop(command):
    num=0
    ln_cmd = len(command)
    while(num<ln_cmd):
        #p = subprocess.Popen(command, shell=True, stdin=None, stdout=None, stderr=subprocess.PIPE, close_fds=True,universal_newlines=True)
        #poller(p)
        urlFetch(command[num])
        num = num+1
        print("------------process {} completed------------------",num)

def poller(p):
    pl = p.poll()
    if pl is None:
        print("running, ",p.pid)
        time.sleep(1)
        poller(p)

if(str(concurrency).lower()=="yes"):
    launch_concurrent_loop(command)
    #tracer(list_processes)
elif(str(concurrency).lower()=="no"):
    sequential_loop(command)
    #tracer(list_processes)