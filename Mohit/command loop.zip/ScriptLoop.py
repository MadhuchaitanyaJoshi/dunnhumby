import json
import subprocess
import time

with open("C:/Users/mjoshi/PycharmProjects/pythonProject/Mohit/conf.json", "r") as config:
    conf = json.load(config)
command = conf["command"]
loop_num = conf["loop_num"]
print(loop_num,type(loop_num))
concurrency = conf["concurrency"]

process = []
def concurrent_loop(command,loop_num):
    for num in range(0,loop_num):
        p = subprocess.Popen(command, shell=True, stdin=None, stdout=None, stderr=subprocess.PIPE, close_fds=True,universal_newlines=True)
        print("-----------completed----------------")
    print("completed---->",len(process))


def sequential_loop(command,loop_num):
    num=0
    while(num<loop_num and len(process)==0):
        p = subprocess.Popen(command, shell=True, stdin=None, stdout=None, stderr=subprocess.PIPE, close_fds=True,
                         universal_newlines=True)
        poller(p)
        num = num+1
        print("------------process {} completed------------------",num)
def poller(p):
    pl = p.poll()
    if pl is None:
        print("running, ")
        time.sleep(1)
        poller(p)

if(str(concurrency).lower()=="yes"):
    concurrent_loop(command,loop_num)
elif(str(concurrency).lower()=="no"):
    sequential_loop(command,loop_num)