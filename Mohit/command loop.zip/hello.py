import time
print("hello world")
time.sleep(5)
print("done saying helo")